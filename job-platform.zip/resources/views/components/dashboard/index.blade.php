<x-dashboard.layout>
    <p class="text-gray-500">Welcome, {{ $user->name }}. Your role is not assigned yet.</p>
</x-dashboard.layout>
