@if($user->is_verified)
    <span style="color: #0d6efd; font-weight: bold;">
        ✔ Verified
    </span>
@endif
