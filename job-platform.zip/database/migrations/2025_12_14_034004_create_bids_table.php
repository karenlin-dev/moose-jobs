<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bids', function (Blueprint $table) {
            $table->id();
            // $table->foreignId('job_id')->constrained()->cascadeOnDelete();
            $table->foreignId('job_id')
                    ->constrained('task_jobs')
                    ->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete(); // worker
            $table->decimal('price', 8, 2);
            $table->text('message')->nullable();
            $table->enum('status', ['pending', 'accepted', 'rejected'])
                ->default('pending');
            $table->timestamps();

            $table->unique(['job_id', 'user_id']); // 防止重复投标
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bids');
    }
};
